Kamus Bahasa Indonesia dan pembagi kata untuk OpenOffice.org
Versi 1.0 - 2004-02-19 : 10803 kata dasar; 3995 petunjuk pembagi kata
Versi 1.1 - 2004-04-05 : 14477 kata dasar; 5035 petunjuk pembagi kata
Versi 1.2 - 2004-08-10 : 35270 kata dasar; 8158 petunjuk pembagi kata

Arsip-arsip id_ID.dic, id_ID.aff dan hyphen_id_ID.dic diciptakan oleh
Pencipta: Benitius Brevoort <benitius.brevoort@kapusin.org>
Hak Cipta (c) 2004 dipegang oleh Pencipta 
di bawah lisensi GNU General Public License, 
sebagaimana tercantum di bawah ini dalam terjemahan Indonesia 
dan teks asli.
Terjemahan Indonesia GNU GPL dikerjakan oleh 
Kelompok Kerja F/KOMAS 2001 (http://www.rms46.vlsm.org/1/30.html#F)
serta disunting oleh 
Rahmat M. Samik-Ibrahim (http://www.rms46.vlsm.org/).

Ejaan kata dan pembagiannya diusahakan sesuai dengan yang tercatat
dalam Kamus Besar Bahasa Indonesia / Tim Penyusun Kamus Pusat
Bahasa, ed. 3 - cet. I. - Jakarta: Balai Pusata, 2001.
Variasi ejaan yang tidak dianjurkan pemakaiannya dalam Kamus Besar
Bahasa Indonesia, tidak dimuat dalam kamus OpenOffice.org ini.

Ucapan terima kasih khusus disampaikan kepada:
Kurniadi <kur@pacific.net.id> dan 
Volker Mueller <vmueller@ukdw.ac.id>
yang menyumbangkan daftar kata kumpulan mereka masing-masing
untuk dimasukkan ke dalam versi 1.1 kamus OpenOffice.org.
Terima kasih juga kepada Arno Brevoort <bre@dnd.utwente.nl>
yang menyumbangkan daftar kata salinan Kamus Besar Indonesia, edisi 2.

Indonesian spell-checker and hyphenator for OpenOffice.org
Version 1.0 - 2004-02-19 : 10803 entries; 3995 hyphenation rules
Version 1.1 - 2004-04-05 : 14447 entries; 5035 hyphenation rules
Version 1.2 - 2004-08-10 : 35270 entries; 8158 hyphenation rules

Archives id_ID.dic, id_ID.aff and hyphen_id_ID.dic 
were created from scratch by
Author: Benitius Brevoort <benitius.brevoort@kapusin.org>
Copyright (c) 2004, held by Author 
under the terms of the GNU General Public License,
reproduced below, after its Indonesian translation.

It has been the explicit goal of the author to make sure that
all entries in the dictionary and the hyphenator follow the
official rules of Indonesian spelling and hyphenation.

Special thanks to 
Kurniadi <kur@pacific.net.id> and 
Volker Mueller <vmueller@ukdw.ac.id> 
who shared their lists of words for inclusion in version 1.1 
of this OpenOffice.org dictionary
Arno J.J. Brevoort <bre@dnd.utwente.nl> 
who shared a full list of words from the Kamus Besar Indonesia, ed. 2

The following is an unofficial translation of the GNU General Public License into Indonesian. It was not published by the Free Software Foundation, and does not legally state the distribution terms for software that uses the GNU GPL--only the original English text of the GNU GPL does that. However, we hope that this translation will help Indonesian speakers understand the GNU GPL better. 

Yang berikut ini merupakan terjemahan tidak resmi dari Lisensi Publik Umum GNU (GNU General Public License) ke dalam bahasa Indonesia. Terjemahan ini tidak dipublikasikan oleh Free Software Foundation (FSF, Yayasan Perangkat Lunak Bebas), serta tidak menyatakan secara hukum ketentuan dari perangkat lunak yang menggunakan GNU GPL--hanyalah versi bahasa Inggris yang resmi yang memiliki kekuatan hukum. Namun, kami harapkan bahwa terjemahan ini akan membantu yang berbahasa Indonesia memahami GNU GPL secara lebih baik. 

GNU GENERAL PUBLIC LICENSE
LISENSI PUBLIK UMUM GNU
Version 2, Juni 1991. 
Hak cipta (C) 1989, 1991 Free Software Foundation, Inc.  
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA

Semua orang diperbolehkan untuk menyalin dan mendistribusikan
salinan sama persis dari dokumen lisensi ini, tetapi mengubahnya
tidak diperbolehkan.
Mukadimah
Hampir semua lisensi dari perangkat lunak dirancang untuk merebut kebebasan anda dan mengubahnya. Sebaliknya, Lisensi Publik Umum GNU (GNU General Public License) bertujuan untuk menjamin kebebasan anda untuk berbagi dan mengubah perangkat lunak bebas -- untuk menjamin bahwa perangkat lunak tersebut tetap bebas bagi penggunanya. General Public License ini dapat diberlakukan terhadap hampir semua perangkat lunak Free Software Foundation dan program lain apa pun yang penciptanya mau menggunakan Lisensi ini. (Beberapa perangkat lunak Free Software Foundation lainnya menggunakan GNU Library Public License.) Anda dapat memberlakukannya terhadap program Anda juga. 
Ketika kita berbicara tentang perangkat lunak bebas, kita mengacu kepada kebebasan, bukan harga. Lisensi Publik Umum kami dirancang untuk menjamin bahwa Anda memiliki kebebasan untuk mendistribusikan salinan dari perangkat lunak bebas (dan memberi harga untuk jasa tersebut jika Anda mau), mendapatkan source code atau bisa mendapatkannya jika Anda mau, mengubah suatu perangkat lunak atau menggunakan bagian dari perangkat lunak tersebut dalam suatu program baru yang juga bebas; dan mengetahui bahwa Anda dapat melakukan semua hal ini. 
Untuk melindungi hak-hak Anda, kami perlu membuat batasan-batasan yang melarang orang lain untuk dapat menolak hak-hak Anda atau membuat Anda menyerahkan hak-hak Anda tersebut. Batasan-batasan ini diterjemahkan menjadi beberapa tanggung jawab bagi Anda jika Anda mendistribusikan salinan dari suatu perangkat lunak, atau memodifikasinya. 
Sebagai contoh, jika Anda mendistribusikan salinan dari suatu program, baik secara gratis atau dengan biaya, Anda harus memberi semua hak-hak Anda kepada si penerima. Anda juga harus menjamin bahwa si penerima tersebut mendapatkan atau bisa mendapatkan source code-nya. 
Kami melindungi hak-hak Anda dengan dua langkah: (1) hak cipta terhadap perangkat lunak tersebut, dan (2) menawarkan Lisensi ini kepada Anda yang memberi Anda izin legal untuk menyalin, mendistribusikan dan/atau memodifikasi perangkat lunak tersebut. 
Demi perlindungan bagi si pencipta dan kami juga, kami ingin memastikan bahwa semua orang mengerti bahwa tidak ada garansi bagi perangkat lunak bebas. Jika perangkat lunak tersebut dimodifikasi oleh orang lain dan didistribusikan, kami ingin sang penerimanya mengetahui bahwa apa yang mereka punyai bukanlah perangkat lunak yang aslinya, sehingga masalah apa pun yang ditimbulkan oleh orang lain tidak mencerminkan reputasi pencipta perangkat lunak yang asli. 
Terakhir, program bebas apa pun terancam terus menerus oleh hak paten perangkat lunak. Kami ingin menghindari bahaya yang memungkinkan redistributor program yang bebas bisa mendapatkan hak paten untuk dirinya sendiri, yang mengakibatkan program tersebut menjadi tak bebas. Untuk mencegah hal ini, kami telah menyatakan dengan jelas bahwa hak paten apa pun harus dilisensikan bagi semua orang, atau tidak sama sekali. 
Berikut adalah ketentuan dan persyaratan yang tepat untuk menyalin, mendistribusikan dan memodifikasi. 

KETENTUAN DAN PERSYARATAN UNTUK MENYALIN, MENDISTRIBUSIKAN DAN MEMODIFIKASI
0. Lisensi ini berlaku untuk program apa pun atau karya lain yang memuat pemberitahuan yang ditempatkan oleh pemegang hak cipta memberitahukan bahwa program atau karya tersebut boleh didistribusikan di bawah persyaratan dari General Public License ini. Sang "Program", di bawah, mengacu pada program atau karya apa pun seperti yang telah disebutkan, dan "karya berdasarkan si Program" berarti si Program itu sendiri atau karya turunan apa pun di bawah hukum hak cipta: yang artinya, suatu karya yang memuat si Program atau bagian darinya, baik itu sama persis atau dengan modifikasi dan/atau diterjemahkan ke dalam bahasa lain. (Mulai dari sekarang, penerjemahan dimasukkan tanpa batas dalam ketentuan "modifikasi".) Setiap pemegang lisensi disebut sebagai "Anda". 
Kegiatan selain menyalin, mendistribusikan dan memodifikasi tidak dilingkupi oleh Lisensi ini; kegiatan tersebut berada di luar ruang lingkup Lisensi ini. Kegiatan menjalankan si Program tidak dibatasi, dan keluaran dari si Program dilingkupi hanya jika isinya mempunyai dasar karya yang berbasis si Program tersebut (terlepas dari keluarannya dibuat dengan cara menjalankan si Program atau tidak). Benar atau tidaknya tergantung pada apa yang dilakukan si Program. 
1. Anda boleh menyalin dan mendistribusikan sama persis dari source code si Program sebagaimana Anda menerimanya, dalam media apa pun, dengan syarat Anda menaruh pemberitahuan yang pantas tentang hak cipta dan penyangkalan terhadap garansi dengan jelas dan sepatutnya pada setiap salinan; menyimpan secara utuh semua pemberitahuan yang mengacu kepada Lisensi ini dan kepada ketiadaan garansi apa pun; dan memberi kepada penerima lainnya sebuah salinan dari Lisensi ini bersama si Program. 
Anda boleh memberi harga untuk kegiatan memindahkan salinan secara fisik, dan Anda boleh, sesuai pilihan Anda, menawarkan perlindungan garansi untuk harga tertentu. 
2. Anda boleh memodifikasi satu atau lebih salinan si Program atau bagian dari si Program yang Anda miliki, sehingga membentuk suatu karya yang berdasarkan si Program, dan menyalin serta mendistribusikan modifikasi atau karya seperti yang telah disebutkan dalam ketentuan pada Bagian 1 di atas, dengan syarat Anda juga memenuhi semua persyaratan ini: 
a) Anda harus membuat agar berkas-berkas yang termodifikasi membawa pemberitahuan menyolok yang memberitahukan bahwa Anda telah mengubah berkas-berkas tersebut dan tanggal perubahan tersebut. 
b) Anda harus menghasilkan karya yang Anda sebarkan atau edarkan, baik seluruhnya atau sebagian atau di hasilkan dari suatu program atau dari berbagai bagian, untuk dilisensikan secara keseluruhan tanpa biaya kepada seluruh partai ketiga di bawah lisensi tersebut. 
c) Jika program yang dimodifikasi saat dijalankan dapat membaca perintah-perintah secara interaktif, Anda harus dapat mewujudkannya, saat memulai menjalankan sesuatu interaktif dengan cara yang paling wajar, mencetak atau menampilkan suatu pengumuman termasuk pemberitahuan hak cipta dan tidak adanya garansi (atau lainnya, yang mengatakan kalau Anda menyediakan garansi, dan pemakai boleh mengedarkan program tersebut berdasarkan suatu kondisi/persyaratan, dan beritahukan kepada mereka bagaimana caranya melihat salinan dari lisensi tersebut. (Pengecualian : Jika program itu sendiri adalah interaktif tapi tidak mencetak pemberitahuan seperti di atas, karya Anda yang berdasarkan program tersebut juga tidak diharuskan mencetak pemberitahuan tersebut.) 
Persyaratan-persyaratan ini diperuntukkan untuk karya yang dimodifikasi secara keseluruhan. Jika bagian yang dapat diidentifikasi dari karya tersebut tidak berasal dari suatu program, dan dapat dinyatakan berdiri sendiri dan suatu karya yang terpisah, maka Lisensi ini, dan bagian-bagiannya, tidak berlaku untuk bagian tersebut saat Anda mengedarkannya sebagai suatu karya yang terpisah. Namun, saat Anda mengedarkan bagian yang sama sebagai bagian dimana karya tersebut merupakan bagian dari program, pengedaran dari yang keseluruhan harus berdasarakan lisensi tersebut, yang perizinannya untuk lisensi yang lain diperluas ke seluruhnya, dan pada setiap bagian tidak peduli siapa yang menulisnya. 
Maka, bukanlah tujuan dari bagian ini untuk mengklaim hak-hak atau memamerkan hak-hak Anda untuk bekerja menulis seluruhnya oleh Anda; daripada, tujuannya adalah untuk melatih hak untuk mengendalikan pendistribusian dari karya turunan atau kolektif berdasarkan si Program tersebut. 
Sebagai tambahan, agregasi belaka dari karya yang lain tidak berdasarkan dari si Program dengan si Program (atau dengan suatu karya berdasarkan si Program) pada kapasitas penyimpanan atau media pendistribusian tidak membawa karya lainnya di bawah lingkup dari Lisensi tersebut. 
3. Anda boleh menyalin dan menyalurkan si Program (atau karya yang berdasarkan si Program tersebut, tercantum pada Bagian 1 dan 2) dalam object code atau bentuk yang dapat dijalankan seperti pada ketentuan yang tercantum pada Bagian 1 dan 2 di atas, dengan syarat Anda juga melakukan salah satu dari hal berikut: 
a) Menyertakannya dengan source code bersangkutan yang lengkap dan dapat dibaca, yang harus didistribusikan di bawah ketentuan yang tercantum pada Bagian 1 dan 2 di atas pada suatu media yang dipergunakan secara khusus untuk pertukaran perangkat lunak; atau, 
b) Menyertakannya dengan penawaran tertulis, yang berlaku untuk setidaknya tiga tahun, untuk memberi pihak ketiga mana pun, dengan suatu harga yang tidak melebihi biaya untuk melakukan pendistribusian sumber, source code bersangkutan yang lengkap dan dapat dibaca, untuk didistribusikan di bawah ketentuan dari Bagian 1 dan Bagian 2 di atas pada suatu media yang dipergunakan secara khusus untuk pertukaran perangkat lunak; atau, 
c) Menyertakannya dengan informasi yang Anda terima berhubungan dengan penawaran untuk mendistribusikan source code yang bersangkutan. (Alternatif ini diperbolehkan hanya untuk distribusi non-komersil dan hanya jika Anda memperoleh program dalam bentuk object code atau bentuk yang dapat dijalankan dengan penawaran seperti yang telah disebutkan, menurut Subbagian b di atas.) 
Source code dari sebuah karya berarti bentuk yang diinginkan dari pekerjaan untuk memodifikasinya. Untuk sebuah karya yang dapat dijalankan, source code lengkap artinya semua source code untuk semua modul yang dikandungnya, ditambah berkas-berkas definisi yang berhubungan, ditambah script yang digunakan untuk mengendalikan kompilasi dan instalasi dan bentuk yang dapat dijalankannya. Bagaimanapun, sebagai pengecualian, pendistribusian source code tidak diperlukan untuk memasukkan semua komponen yang biasanya didistribusikan (dalam bentuk source atau biner) bersama dengan komponen utama (kompilator, kernel, dan sebagainya) dari sistem operasi dimana program tersebut berjalan, kecuali komponen tersebut mendampingi bentuk yang dapat dijalankannya. Jika pendistribusian dari bentuk yang dapat dijalankannya dan object code dibuat dengan penawaran akses untuk menyalin dari tempat yang telah ditentukan, maka penawaran akses untuk menyalin source code dari tempat yang sama dihitung sebagai pendistribusian dari source code, walaupun pihak ketiga tidak diharuskan untuk menyalin source code bersama-sama dengan object code. 
4. Anda tidak boleh menyalin, mengubah, mensublisensikan, atau mendistribusikan si Program tersebut kecuali sebagaimana telah diterangkan pada Lisensi ini. Segala usaha untuk menyalin, mengubah, mensublisensikan, atau mendistribusikan si Program tersebut adalah tidak sah, dan secara otomatis akan membatalkan hak-hak Anda di bawah Lisensi ini. Akan tetapi, mereka yang sudah mendapatkan salinan, atau hak-hak dari Anda di bawah Lisensi ini tidak akan dibatalkan lisensinya selama mereka tetap mematuhi Lisensi ini. 
5. Anda tidak diharuskan menerima Lisensi ini, karena anda belum menyetujuinya. Tetapi, tidak ada lisensi lain yang memberi anda izin untuk memodifikasi atau mendistribusikan Program tersebut atau turunannya. Kegiatan tersebut dilarang oleh hukum jika anda tidak menerima Lisensi ini. Oleh karena itu, dengan memodifikasi atau mendistribusikan program tersebut (atau hasil kerja berdasarkan program tersebut), berarti Anda menerima Lisensi ini, dan semua ketentuan serta kondisi untuk menyalin, mendistribusikan atau memodifikasi program tersebut atau hasil kerja berdasarkan program tersebut. 
6. Setiap kali anda mendistribusikan si Program tersebut (atau hasil kerja lain berdasarkan Program tersebut), penerima secara otomatis menerima lisensi dari pemberi lisensi untuk menyalin, mendistribusikan atau memodifikasi si Program tersebut berdasarkan persyaratan dan kondisi yang ada. Anda tidak boleh memberikan pembatasan lain terhadap perilaku penerima terhadap hak-hak yang telah diberikan . Anda tidak bertanggung jawab untuk memaksakan penyesuaian pihak ketiga terhadap Lisensi ini. 
7. Jika sebagai konsekuensi dari keputusan pengadilan atau pelanggaran paten atau hal yang lainnya (tidak terbatas kepada permasalahan paten), kondisinya tergantung pada anda (jika ada suruhan dari pengadilan, kesepakatan atau yang lainnya) yang berbeda dari Lisensi ini, mereka tidak menerima kesepakatan Lisensi ini. Jika kita tidak bisa menyebarkan agar dapat secara simultan terpuaskan kesepakatan di bawah Lisensi ini dan kesepakatan yang lainnya, kemudian sebagai konsekuensi nya kita tidak dapat mengedarkan seluruh program sama sekali. Sebagai contoh, jika lisensi paten tidak membolehkan pembayaran royalti (hak pakai) dari program dimana pengguna menerima salinannya secara langsung atau tidak langsung dari Anda, maka satu-satunya jalan untuk Anda memuaskan antara yang menerima salinan dan Lisensi ini adalah untuk menjelaskan keseluruhan distribusi program. 
Jika ada bagian dari sini termasuk tidak sah atau tidak dapat diterapkan di bawah keadaan tertentu apa pun juga, keseimbangan dari bagian ini bertujuan untuk menerapkan dan bagian ini sebagai keseluruhan adalah diperuntukkan untuk menerapkan hal yang lainnya. 
Ini bukan bermaksud untuk mempengaruhi Anda untuk melanggar paten tertentu atau klaim hak kepemilikan yang lain atau untuk mengadu keabsahan klaim hak kepemilikan apa pun; bagian ini mempunyai maksud dan tujuan untuk melindungi integritas dari sistem pendistribusian perangkat lunak bebas, dimana perangkat lunak itu diimplementasikan oleh praktek lisensi umum. Banyak orang sekarang telah dapat membuat kontribusi umum untuk mendistribusikan penggunaan perangkat lunak dalam sebuah sistem yang terbuka; hal ini tergantung dari si pencipta/penderma jika ia punya keinginan untuk menyebarkan/tidak menyebarkan aplikasi yang ia buat ke masyarakat luas tanpa mengikuti sistem yang berlaku dan pemegang lisensi tidak dapat menentukan pilihan tersebut. 
Bagian ini bertujuan untuk membuat sebuah pemahaman yang jelas tentang apa yang dipercayai sebagai akibat dari sisa Lisensi ini. 
8. Jika distribusi dan/atau penggunaan si Program dibatasi di negara-negara tertentu saja melalui paten atau hak cipta antar muka, pemegang hak cipta orisinil yang menempatkan si Program di bawah Lisensi ini boleh menambahkan batasan pendistribusian geografis secara ekplisit terkecuali negara-negara yang disebut di atas, sehingga distribusi hanya terdapat di dalam atau di antara negara-negara yang diperbolehkan. Dalam kasus semacam itu, Lisensi ini menyertakan limitasi di atas sebagaimana tertulis di dalam tubuh Lisensi ini. 
9. Free Software Foundation diperbolehkan menerbitkan versi revisi atau versi baru dari General Public License dari waktu ke waktu. Versi baru semacam itu akan tetap memiliki semangat yang sama dengan versi sebelumnya, tapi dapat berbeda detil untuk menangani problem baru atau perhatian baru. 
Setiap versi diberikan nomor versi yang berbeda-beda. Jika si Program menyatakan nomor versi dari Lisensi ini yang diberlakukan dalam Program tersebut dan versi-versi berikutnya dari Program tersebut, Anda memiliki pilihan untuk mengikuti syarat dan kondisi dari versi ini atau salah satu versi berikutnya yang diterbitkan oleh Free Software Foundation. Jika Program tidak menyatakan nomor versi dari Lisensi ini, Anda boleh memilih sembarang versi yang diterbitkan oleh Free Software Foundation. 
10. Jika Anda menginginkan untuk menyertakan bagian dari Program ke dalam program bebas yang lain yang kondisi distribusinya berbeda, Anda harus menanyakan kepada penulis program. Untuk software yang dihakciptakan oleh Free Software Foundation, anda harus menanyakan ke Free Software Foundation; kami kadang kala membuat pengecualian dalam hal ini. Keputusan kami akan ditentukan oleh dua hal yaitu untuk menjaga status bebas dari semua turunan perangkat lunak bebas kami dan untuk mempromosikan pengunaan bersama dan penggunaan kembali dari perangkat lunak secara umum. 
TIDAK ADA GARANSI 
11. KARENA IZIN PROGRAM BEBAS BIAYA, TAK ADA JAMINAN TAMBAHAN UNTUK PROGRAM SAMPAI BATASAN YANG DITENTUKAN OLEH HUKUM YANG ADA. KECUALI JIKA ADA TULISAN YANG DISEBUTKAN OLEH PEMEGANG HAK CIPTA DAN ATAU KELOMPOK LAIN YANG MENYEDIAKAN PROGRAM SEBAGAI TANPA JAMINAN JENIS APAPUN, BAIK SECARA LANGSUNG MAUPUN TIDAK LANGSUNG, TERMASUK, TAPI TAK TERBATAS, JAMINAN DAYA JUAL DAN TUJUAN-TUJUAN TERTENTU. SEMUA RESIKO DARI KUALITAS DAN KEHANDALAN PROGRAM DITANGGUNG ANDA SENDIRI, JIKA TERJADI PROGRAM TERNYATA CACAT ATAU KURANG SEMPURNA, ANDA MEMBUAT ASUMSI DARI BIAYA PERBAIKAN, PEMBETULAN DAN KOREKSI SEPERLUNYA. 
12. TIDAK DALAM KEADAAN APA PUN KECUALI DIBUTUHKAN OLEH HUKUM YANG ADA ATAU DISETUJUI DALAM TULISAN PEMEGANG HAK CIPTA, ATAU PIHAK LAIN YANG MEMODIFIKASI DAN MENDISTRIBUSIKAN PROGRAM SEPERTI YANG DIIZINKAN DI ATAS, ANDA BERTANGGUNG JAWAB ATAS KERUSAKAN , TERMASUK SECARA UMUM, KERUSAKAN KHUSUS, SENGAJA MAUPUN TIDAK DISENGAJA, YANG MENYEBABKAN PROGRAM TAK BISA DIGUNAKAN (TERMASUK, TAPI TAK TERBATAS HANYA PADA HAL TERSEBUT KEHILANGAN DATA ATAU DATA MENJADI TIDAK AKURAT, DISEBABKAN OLEH ANDA ATAU PIHAK KETIGA, ATAU KEGAGALAN PROGRAM UNTUK BEKERJASAMA DENGAN PROGRAM LAIN ), WALAU BAHKAN JIKA PEMEGANG HAK CIPTA ATAU PIHAK LAIN TELAH DIPERINGATKAN TENTANG KEMUNGKINAN KERUSAKAN TERSEBUT. 
AKHIR KETENTUAN SERTA PERSYARATANNYA


                    GNU GENERAL PUBLIC LICENSE
                       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
                       59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation's software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author's protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone's free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.

                    GNU GENERAL PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program's
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

                            NO WARRANTY

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

                     END OF TERMS AND CONDITIONS

            How to Apply These Terms to Your New Programs

  If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these terms.

  To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
convey the exclusion of warranty; and each file should have at least
the "copyright" line and a pointer to where the full notice is found.

    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) <year>  <name of author>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Also add information on how to contact you by electronic and paper mail.

If the program is interactive, make it output a short notice like this
when it starts in an interactive mode:

    Gnomovision version 69, Copyright (C) year name of author
    Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w'.
    This is free software, and you are welcome to redistribute it
    under certain conditions; type `show c' for details.

The hypothetical commands `show w' and `show c' should show the appropriate
parts of the General Public License.  Of course, the commands you use may
be called something other than `show w' and `show c'; they could even be
mouse-clicks or menu items--whatever suits your program.

You should also get your employer (if you work as a programmer) or your
school, if any, to sign a "copyright disclaimer" for the program, if
necessary.  Here is a sample; alter the names:

  Yoyodyne, Inc., hereby disclaims all copyright interest in the program
  `Gnomovision' (which makes passes at compilers) written by James Hacker.

  <signature of Ty Coon>, 1 April 1989
  Ty Coon, President of Vice

This General Public License does not permit incorporating your program into
proprietary programs.  If your program is a subroutine library, you may
consider it more useful to permit linking proprietary applications with the
library.  If this is what you want to do, use the GNU Library General
Public License instead of this License.

